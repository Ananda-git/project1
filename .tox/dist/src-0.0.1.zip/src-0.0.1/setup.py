from setuptools import setup, find_packages

setup(
    name = "src",
    version = "0.0.1",
    description ="Project case study for Oracle blr",
    author = "Dr. Rao",
    packages = find_packages(),
    license= "MIT"
)